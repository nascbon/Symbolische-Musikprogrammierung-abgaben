; Symbolische Musikprogrammierung (Semester 1, SPLC1+MASP1)
; IMWI - HfM Karlsruhe
; Wintersemester 2024/2025
; Dozent: Prof. Dr. Marlon Schumacher
;
; === Klausur 04.02.2025 ===

(in-package :om)



; ==== SYMBOLISCHE PROGRAMMIERUNG IN COMMON LISP ====

;# 1. VARIABLEN

; Programmieren Sie eine Funktion zur statistischen Tonh�henerfassung, welche aus einer Sequenz von Tonh�hen ein "Histogramm" von Tonh�henklassen (pitch-classes) bildet, und diese in einer globalen Variable speichert.  

; Eingabeargumente der Funktion sind die Liste von Tonh�hen in midicent, Ausgabe/R�ckgabewert ist eine Liste von Ganzzahlen, deren Index der jeweiligen Tonh�henklasse entspricht (folglich m�ssen also 11 Werte in der Liste enthalten sein), der Wert stellt die H�ufigkeit der Tonh�henklassen f�r den spezifischen Index dar. Zum Beispiel: '(0 0 5 0 0 0 0 0 0 0 0 0)  bedeutet, dass die Tonh�henklasse 2 eine H�ufigkeit von 5 besitzt.
 
; Tipp: es gibt mindestens 2 Ans�tze daf�r. 
;# => 20 Punkte


; Schreiben Sie Ihren Code bitte Unterhalb zwischen u.s. Linien.
; Bitte illustrieren Sie mit einem kurzen Beispiel.
; --------------------------
(defparameter *histogramm* nil)

(defun histogram-function (midicents)
  (let ((list-histo (make-list 12 :initial-element 0)))
    (dolist (mc midicents)
      (let ((pc (mod (round mc 100) 12)))  
        (incf (nth pc list-histo)))) (setf *histogramm* list-histo) 
    list-histo)
  )


 (histogram-function '(100 200 500 200 300 600 700 200 100 0))



; --------------------------


;# 2. SCHLEIFEN / REKURSION


; Programmieren Sie eine Funktion "my-group-list". Diese Funktion sollte als Eingabeargumente eine Liste von beliebigen Elementen akzeptieren, sowie eine Ganzzahl. Die Funktion sollte nun diese Liste in Sublisten gruppieren, deren Anzahl von Elmenten der Ganzzahl entspricht.

; Beispiel: 
; Eingabeliste: (1 2 3 4 5 6 7), Ganzzahl: 2
; Ausgabeliste: ((1 2) (3 4) (5 6))

; a) mithilfe einer Loop Schleife:  20 Punkte
; b) mithilfe einer Do Schleife: 25 Punkte (5 Bonus)
; c) mithilfe von Rekursion: 30 Punkte (10 Bonus)

; Schreiben Sie Ihren Code bitte Unterhalb zwischen u.s. Linien.
; Bitte illustrieren Sie mit einem kurzen Beispiel.
; --------------------------

(defun my-group-list (list Anzahl)
   (do ((output nil) (sublist list (nthcdr Anzahl sublist)))
      ((null sublist) (nreverse output))
    (push (subseq sublist 0 (min Anzahl (length sublist))) output)
    )
   )

(my-group-list '(1 2 3 4 5 6 7 8) 3)

; --------------------------


;# 3. BEDINGTE ANWEISUNGEN

;# Programmieren Sie unter Verwendung von Schleifen eine Urnen-Funktion 'my-urn', die aus einer Liste von beliebigen (verschiedenen) Elementen, zuf�llig Elemente zieht, und diese gezogenen Elemente als neue Liste ausgibt. Die Anzahl der gezogenen Elemente soll als Argument angegeben werden k�nnen. Jedes Element kann dabei nur einmal gezogen werden, folglich ist die maximale L�nge der Ausgabeliste = Eingabeliste. 
;Bsp:  (my-urn '(a b c d e) 3) => (d a e)

;# Sie d�rfen folgende Konstrukte verwenden (eine der drei L�sungen gen�gt).
;# a) LOOP => 20 Punkte
;# b) DO => 20 Punkte
;# c) Rekursiv oder Endrekursiv => 30 Punkte (10 Bonus)

; Schreiben Sie Ihren Code bitte Unterhalb zwischen u.s. Linien.
; Bitte illustrieren Sie mit einem kurzen Beispiel.
; --------------------------

(defun my-urn (list length)
  (let ((randomN) (output '()) (urn list))
    (dotimes (i length (reverse output))
      (unless (null urn)
        (progn (setf randomN (random (length urn))) (push (nth randomN urn) output) (setf urn (remove (nth randomN urn) urn))))
    )
  )
)

(my-urn '(1 2 3 4 5 6 7 8 9 10) 4)
; --------------------------

; Summe: 60 Punkte (20 Bonus)


; ==== MUSIKALISCHE ANWENDUNGEN IN OPEN MUSIC ====

; In diesem Teil schreiben Sie einen Prozess, in dem Verfahren der Wiederholung und Phasenverschiebung, wie beispielsweise in der Minimal Music der 60er Jahre thematisiert, eine zentrale Rolle spielen. Nehmen Sie den OpenMusic patch als Ausgangspunkt. 

; Aus dem Material einer musikalischen Sequenz in einem 'chord-seq' Objekt soll ein sich sukzessiv/inkrementell ausdehnender Prozess entstehen, welcher sich auf unterschiedliche Parameter mit unterschiedlichen Phasendauern manifestiert. Bitte erstellen Sie mit dem neu erzeugten Material ein neues Chord-seq Objekt, wie im OpenMusic patch dargestellt. NB: Sie koennen zur Loesung sowohl grafische Funktionen aus OpenMusic, als auch LISP code verwenden.

; a) das Tonh�henmaterial aus dem ersten chord-seq Objekt soll durch einen algorithmischen Prozess �ber Indizes zugegriffen und neu sequenziert werden. Hierbei sollte eine inkrementell regelm��ige aufsteigende Abfolge von Indizes ("k" Schritte = eine Phase) sich zyklisch ("z" = Anzahl der Wiederholungen) wiederholen, wobei in jeder Wiederholung (Phase) den Indizes ein inkrementell regelm��ig aufsteigendes Offset "o" hinzugef�gt wird. Zum Beispiel: 

; Eine "Phase" in k=4 Schritten: (1 2 3 4); 
; Zyklische Wiederholung: '((1 2 3 4) (1 2 3 4) (1 2 3 4) ... ) 
; Offset o=1: '((1 2 3 4) (2 3 4 5) (3 4 5 6) ...)

; NB: wenn visualisiert, �hnelt diese Gestalt einem aufsteigenden S�gezahn, (s. OpenMusic patch)

; => 20 Punkte

; --------------------------

; b) derselbe Prozess sollte zu Selektion+Sequenzierung der Einsatzzeitpunkte (= onset times) eingesetzt werden. Hierzu m�ssen diese absoluten Zeitpunkte zun�chst zu relativen Zeitabst�nden (quasi zeitliche Intervalle) umgewandelt werden, die wiederum �ber Indizes neu sequenziert und anschlie�end zu neuen Zeitpunkten umgewandelt/integriert werden k�nnen.

; => 15 Punkte

; --------------------------

; c) zur Berechnung der Dynamik sollten die (relativen) ersten k Ausgabewerte der Fibonacci Reihe (z.B. '(1 2 3 5 8)) berechnet und anschliessend in einen Wertebereich von 8 bis 64 (Midi velocities) skaliert werden. Anschlie�end findet ein �hnlicher Prozess zu a) statt: die Liste der Werte aus der Fibonacci Reihe ("n" Werte = eine Phase) sollte sich zyklisch wiederholen, wobei nun jede Wiederholung (Phase) um ein inkrementell regelm��ig aufsteigendes Rotationsintervall "r" rotiert wird. Es ist dabei darauf zu achten, dass die Gesamtzahl der Schritte der Gesamtzahl von Tonh�hen entspricht. D.h. k*z = n*r Sie darauf Zum Beispiel: 
   
; Eine "Phase" in n=5 Schritten: '(1 2 3 5 8); 
; Zyklische Wiederholung: '((1 2 3 5 8) (1 2 3 5 8) (1 2 3 5 8) ... ); 
; Rotationsintervall r=1: '((1 2 3 5 8) (2 3 5 8 1) (3 5 8 1 2) ... ) 

; => 25 Punkte

; Summe: 60 Punkte

; --------------------------

;# Summe gesamt (SPCL+MASP): 120 Punkte = 100%
;# Bonus: 20 Punkte

;# Bitte schreiben Sie Ihre Loesungen direkt in diesen Buffer und speichern diese als LISP Datei. Ihre OpenMusic patches koennen aus dem Workspace heraus mit dem Kontextmenue exportiert werden, ebenso in OpenMusic geschriebene LISPFUNCTION Objekte. Bitte archivieren Sie alles zusammen (LISP files, patches) in einer .zip Datei, die Sie mit Ihrem Namen benennen.

; # Wichtig: Materialien aus der Lehrveranstaltung d�rfen verwendet werden; allerdings keine Programmierassistenten (Chat-GPT, Copilot, etc.)

;# Fragen?  

;# Tipp: Sollten Sie an einer Stelle ins Stocken geraten, fahren Sie mit den Aufgaben fort, die entweder 
; a) am schnellsten zu loesen sind, oder 
; b) wofuer die meisten Punkte vergeben werden.


; #### VIEL ERFOLG ####